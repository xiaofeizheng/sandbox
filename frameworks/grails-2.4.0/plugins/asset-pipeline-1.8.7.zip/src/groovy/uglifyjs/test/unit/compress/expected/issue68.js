function f(){function b(){}if(a)return;b()}
